package com.talentshare.mentor;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class TlsMentorRegDemoV1ApplicationTests {

	@Test
	void contextLoads() {
	}

}
