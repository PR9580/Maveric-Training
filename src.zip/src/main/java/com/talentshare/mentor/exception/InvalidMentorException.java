package com.talentshare.mentor.exception;

public class InvalidMentorException extends RuntimeException{
	
	public InvalidMentorException(String message) {
		super(message);
	}

}
